export function sequence(max) {
        var items = [];
        for(var i = 0; i < max; i ++){
            items.push(i);
        }
        return items;
    }